package elevator_1316;

public class elevator extends  floor{
	int numberOfFloors,floorChoice;

	@Override
	void switchState(context c) {
		// TODO Auto-generated method stub
		
	}
	
}
