package elevator_1316;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		context ca =new context(new floorDownState());
		ca.switchState();
		ca.switchState();
		ca.switchState();
		}

	}


