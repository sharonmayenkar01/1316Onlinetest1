package elevator_1316;

public class door {
	boolean doorStatus;
	void openDoor(){
		System.out.println("Door opened");
		}
		void closeDoor(){
			System.out.println("Door closed");
		}
}
